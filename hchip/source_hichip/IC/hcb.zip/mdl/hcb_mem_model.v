`timescale 1ns/1ps

module hcb_mem_model (
    input               clk,
    input               resetn,
    input               hcb_req,
    input               hcb_rw,
    input       [3:0]   hcb_be,
    input       [31:2]  hcb_addr,
    input       [31:0]  hcb_wdata,
    output  reg [31:0]  hcb_rdata,
    output  reg         hcb_ack
);
    localparam MEM_DEPTH = 16384;

    reg [7:0] mem [0:MEM_DEPTH-1];

    reg [2:0] ack_delay;
    reg       pending;
    reg       pending_rw;
    reg [3:0] pending_be;
    reg [31:2] pending_addr;
    reg [31:0] pending_wdata;
    reg [31:0] prng;

    integer i;
    integer base;
    integer lane;
    reg [31:0] rdata_tmp;

    always @(posedge clk or negedge resetn) begin
        if (!resetn) begin
            hcb_ack       <= 1'b0;
            hcb_rdata     <= 32'h0;
            ack_delay     <= 3'd0;
            pending       <= 1'b0;
            pending_rw    <= 1'b0;
            pending_be    <= 4'h0;
            pending_addr  <= 30'h0;
            pending_wdata <= 32'h0;
            prng          <= 32'h1234_5678;
            for (i = 0; i < MEM_DEPTH; i = i + 1) begin
                mem[i] <= 8'h0;
            end
        end else begin
            hcb_ack <= 1'b0;
            prng <= {prng[30:0], prng[31] ^ prng[21] ^ prng[1] ^ prng[0]};

            if (!pending && hcb_req) begin
                pending       <= 1'b1;
                pending_rw    <= hcb_rw;
                pending_be    <= hcb_be;
                pending_addr  <= hcb_addr;
                pending_wdata <= hcb_wdata;
                // Deterministic 1~3 cycle response latency.
                ack_delay     <= {1'b0, prng[1:0]} + 3'd1;
            end else if (pending) begin
                if (ack_delay != 3'd0) begin
                    ack_delay <= ack_delay - 3'd1;
                end else begin
                    base = {pending_addr, 2'b00};
                    if (pending_rw) begin
                        for (lane = 0; lane < 4; lane = lane + 1) begin
                            if (pending_be[lane]) begin
                                mem[base + lane] <= pending_wdata[lane*8 +: 8];
                            end
                        end
                    end else begin
                        rdata_tmp = 32'h0;
                        for (lane = 0; lane < 4; lane = lane + 1) begin
                            rdata_tmp[lane*8 +: 8] = mem[base + lane];
                        end
                        hcb_rdata <= rdata_tmp;
                    end
                    hcb_ack  <= 1'b1;
                    pending  <= 1'b0;
                end
            end
        end
    end

endmodule
