# HCB协议介绍

## 信号接口表

| 信号名 | 位宽 | 方向 | 说明 |
|--------|------|------|------|
| clk | 1 | - | 时钟信号 |
| ip_hcb_req | 1 | Master→Slave | HCB请求信号 |
| ip_hcb_rw | 1 | Master→Slave | 0:read, 1:write（读写控制） |
| ip_hcb_be[3:0] | 4 | Master→Slave | byte enable（字节使能） |
| ip_hcb_addr[31:2] | 30 | Master→Slave | HCB地址（字对齐，低2位省略） |
| ip_hcb_wdata[31:0] | 32 | Master→Slave | HCB写数据 |
| ip_hcb_rdata[31:0] | 32 | Slave→Master | HCB读数据 |
| ip_hcb_ack | 1 | Slave→Master | HCB应答信号 |

**方向说明：**
- **Master→Slave**：信号由主控端（Master）发出，从设备端（Slave）接收
- **Slave→Master**：信号由从设备端（Slave）发出，主控端（Master）接收
- **Master**：通常是控制器，发起HCB访问请求
- **Slave**：通常是缓存控制器（HCB），响应访问请求并提供数据

## 信号详细说明

### 控制信号（握手协议）
- **clk**: 时钟信号，所有信号在时钟上升沿采样
- **ip_hcb_req**: HCB请求信号，主控端发起，高电平表示有效的HCB访问请求
- **ip_hcb_ack**: HCB应答信号，从设备端响应，高电平表示请求已被接受并完成
- **握手机制**: 当 `ip_hcb_req` 为高电平时发起请求，`ip_hcb_ack` 拉高表示传输完成（握手成功）
- **ip_hcb_rw**: 读写控制信号
  - 0: 读操作
  - 1: 写操作

### 地址和数据
- **ip_hcb_addr[31:2]**: HCB访问地址，30位地址总线（字对齐，实际地址为{addr[31:2], 2'b00}）
- **ip_hcb_be[3:0]**: 字节使能信号，4位对应32位数据的4个字节（**仅用于写操作**）
  - be[0]: 对应wdata[7:0]
  - be[1]: 对应wdata[15:8]
  - be[2]: 对应wdata[23:16]
  - be[3]: 对应wdata[31:24]
  - 写操作时：be=1表示对应字节有效，需要写入；be=0表示对应字节无效，不写入
  - 读操作时：be信号不使用，始终读取整个字（32位）
- **ip_hcb_wdata[31:0]**: 写数据总线，32位宽
- **ip_hcb_rdata[31:0]**: 读数据总线，32位宽

## 时序说明

### 1. Write Operation - HCB写操作

<img src="./hcb_write.svg" alt="HCB写操作时序图" width="100%">

> **说明**：此时序图展示的是HCB协议的写操作时序，传输128位数据。

#### 时序图说明

上图展示了HCB协议的写操作时序。写操作采用握手机制：地址和数据在同一周期传输。

**关键特性：请求-应答握手机制**
- Master在发起命令时同时提供地址、数据和字节使能
- Slave在准备好后拉高ack信号
- req可以保持多个周期，直到ack拉高完成握手

**时钟周期分析：**

| 周期 | Master | Slave | 说明 |
|------|--------|-------|------|
| T0 | 空闲 | 空闲 | 空闲状态 |
| T1 | 上升沿拉起req=1<br>addr/wdata/be有效<br>rw=1（写操作） | ack=0 | Master发起写请求 |
| T2-Tn | 保持req=1和所有信号稳定 | 检查内部状态<br>处理写操作<br>ack=0 | Slave处理写请求 |
| Tn+1 | 保持req=1和所有信号稳定 | **ack=1（上升沿拉高）**<br>写操作完成 | Slave拉高ack表示完成 |
| Tn+2 | 上升沿采样到ack=1<br>握手成功<br>**req拉低为0** | **ack拉低为0** | 双方确认握手<br>ack仅持续1个周期 |
| Tn+3+ | 空闲或发起新请求 | 空闲 | 传输完成 |

**详细握手流程：**

**阶段1：Master发起写请求（T1周期）**

Master端操作：
1. **命令和数据同时发起**：
   - 在T1时钟上升沿拉起`ip_hcb_req = 1`
   - `ip_hcb_rw = 1`（写操作）
   - `ip_hcb_addr[31:2]`：访问地址（字对齐）
   - `ip_hcb_wdata[31:0]`：写数据
   - `ip_hcb_be[3:0]`：字节使能（指定哪些字节需要写入，例如0xf表示全部字节）

2. **稳定性承诺**：
   - 所有信号保持稳定，直到Master采样到`ip_hcb_ack = 1`

**阶段2：Slave处理写请求（T2-Tn周期）**

Slave端操作：
- 检测到`ip_hcb_req = 1`
- 采样所有信号（`ip_hcb_addr`, `ip_hcb_rw`, `ip_hcb_wdata`, `ip_hcb_be`）
- 检查内部状态：
  - 当前是否有未处理完的资源冲突
  - 是否可以接收新的写事务
- 处理写操作：
  - 根据be信号将wdata写入对应地址
  - 完成后准备拉高ack

> **关键时序特性**：
> - Slave在req=1期间采样所有信号
> - 处理时间取决于内部状态，可能需要多个周期
> - req信号必须保持稳定直到ack拉高

**阶段3：Slave拉高ack（Tn+1周期）**

Slave端：
- 写操作完成
- **在Tn+1时钟上升沿拉高`ip_hcb_ack = 1`**
- ack仅持续1个周期

**阶段4：Master确认握手（Tn+2周期）**

Master端：
- 在Tn+2时钟上升沿采样到`ip_hcb_ack = 1`
- 确认握手成功
- **拉低`ip_hcb_req = 0`**
- 之后可以改变所有信号或发起新的传输

Slave端：
- **在Tn+2时钟上升沿拉低`ip_hcb_ack = 0`**（ack仅持续1个周期）
- 数据已写入完成

**阶段5：完成（Tn+3周期）**
- 返回空闲状态或发起新的传输

**关键时序要求：**

1. **请求-应答握手机制**：
   - Master发起req时同时提供地址、数据和字节使能
   - req信号保持高电平直到ack拉高
   - ack拉高表示操作完成
   - 这是HCB协议的核心握手机制

2. **信号稳定性**：
   - 所有信号（addr, wdata, be, rw, req）：从T3开始保持稳定，直到Master采样到ack=1
   - Master必须等待采样到ack信号后，才能改变信号

3. **处理延迟（实际情况）**：
   - T0：空闲状态
   - T1：Master在上升沿拉起req，地址和数据准备好
   - T2-Tn：Slave处理写操作（延迟取决于内部状态）
   - Tn+1：Slave拉高ack表示完成
   - Tn+2：Master采样到ack，握手成功
   - 总周期数取决于Slave的处理时间

4. **字节使能控制（写操作）**：
   - be[3:0]信号控制哪些字节需要写入
   - be=1表示对应字节有效，be=0表示对应字节不写入
   - 支持字节、半字、字的灵活写入
   - 例如：be=4'b1111表示写入全部4个字节，be=4'b0001表示只写入最低字节

**握手延迟分析：**

最快情况（假设Slave立即处理完成）：
```
T0: 空闲状态
T1: Master在上升沿拉起req=1，地址和数据准备好
T2: Slave采样信号并处理写操作，拉高ack=1（写操作完成）
T3: Master采样到ack=1，握手成功，req拉低；Slave拉低ack=0
```

延迟情况（Slave需要多个周期处理）：
```
T0: 空闲状态
T1: Master在上升沿拉起req=1
T2-Tn: Slave处理写操作，ack=0（处理中）
Tn+1: Slave拉高ack=1（写操作完成）
Tn+2: Master采样到ack=1，握手成功，req拉低；Slave拉低ack=0
```

### 2. Read Operation - HCB读操作

<img src="./hcb_read.svg" alt="HCB读操作时序图" width="100%">

> **说明**：此时序图展示的是HCB协议的读操作时序，读取128位数据。

#### 时序图说明

上图展示了HCB协议的读操作时序。读操作采用双阶段握手机制：地址阶段握手和数据阶段握手。

**关键特性：请求-应答握手机制**
- Master在发起命令时只需提供地址
- req信号保持高电平直到ack拉高
- Slave在ack拉高时提供rdata
- Master在ack=1的下一个周期采样rdata

**时钟周期分析：**

| 周期 | Master | Slave | 说明 |
|------|--------|-------|------|
| T0 | 空闲 | 空闲 | 空闲状态 |
| T1 | 上升沿拉起req=1<br>addr有效<br>**rw=0（读操作）** | ack=0 | Master发起读请求 |
| T2-Tn | 保持req=1和所有信号稳定 | 检查内部状态<br>从内存读取数据<br>ack=0 | Slave处理读请求 |
| Tn+1 | 保持req=1 | **ack=1（上升沿拉高）**<br>**rdata有效**<br>读操作完成 | Slave拉高ack并提供数据 |
| Tn+2 | 上升沿采样到ack=1<br>**同时采样rdata[31:0]**<br>握手成功<br>**req拉低为0** | **ack拉低为0**<br>rdata保持稳定 | 双方确认握手并采样数据<br>ack仅持续1个周期 |
| Tn+3+ | 空闲或发起新请求 | 空闲 | 传输完成 |

**详细握手流程：**

**阶段1：Master发起读请求（T1周期）**

Master端操作：
1. **命令发起**：
   - 在T1时钟上升沿拉起`ip_hcb_req = 1`
   - `ip_hcb_rw = 0`（读操作）
   - `ip_hcb_addr[31:2]`：访问地址（字对齐）

2. **稳定性承诺**：
   - 命令信号（`ip_hcb_addr`, `ip_hcb_rw`, `ip_hcb_req`）保持稳定，直到Master采样到`ip_hcb_ack = 1`

**阶段2：Slave处理读请求（T2-Tn周期）**

Slave端操作：
- 检测到`ip_hcb_req = 1`且`ip_hcb_rw = 0`
- 采样地址信号（`ip_hcb_addr`）
- 检查内部状态：
  - 当前是否有未处理完的资源冲突
  - 是否可以接收新的读事务
- 处理读操作：
  - 根据地址从内存读取整个字（32位数据）
  - 完成后准备拉高ack并提供rdata

> **关键时序特性**：
> - Slave在req=1期间采样地址信号
> - 读操作始终读取整个字（32位），不使用be信号
> - 处理时间取决于内存访问延迟和内部状态
> - req信号必须保持稳定直到ack拉高

**阶段3：Slave拉高ack并提供数据（Tn+1周期）**

Slave端：
- 读操作完成，数据准备好
- **在Tn+1时钟上升沿拉高`ip_hcb_ack = 1`**
- **同时提供`ip_hcb_rdata[31:0]`**
- ack仅持续1个周期

**阶段4：Master确认握手并采样数据（Tn+2周期）**

Master端：
- 在Tn+2时钟上升沿采样到`ip_hcb_ack = 1`
- **同时采样`ip_hcb_rdata[31:0]`**
- 确认握手成功
- **拉低`ip_hcb_req = 0`**
- 之后可以改变命令信号或发起新的传输

Slave端：
- **在Tn+2时钟上升沿拉低`ip_hcb_ack = 0`**（ack仅持续1个周期）
- 命令信号已在T2-Tn期间采样完成
- rdata可以改变或复位

**阶段5：完成（Tn+3周期）**
- 返回空闲状态或发起新的传输

**关键时序要求：**

1. **读操作特点**：
   - Master只需提供地址信号，不需要提供数据和字节使能
   - be信号在读操作时不使用
   - Slave读取整个字（32位数据）
   - Slave在ack拉高时同时提供rdata
   - Master在ack=1的下一个周期采样rdata
   - 读延迟取决于Slave的数据准备时间

2. **信号稳定性**：
   - **命令信号**（addr, rw, req）：从T3开始保持稳定，直到Master采样到ack=1
   - **读数据信号**（rdata）：Slave在ack=1时提供，Master在下一个周期采样
   - Master必须等待采样到ack=1后才能使用rdata

3. **处理延迟（实际情况）**：
   - T0：空闲状态
   - T1：Master在上升沿拉起req发起读请求
   - T2-Tn：Slave从内存读取数据（延迟取决于内存访问时间）
   - Tn+1：Slave拉高ack并提供rdata
   - Tn+2：Master采样到ack和rdata，握手成功
   - 总周期数取决于Slave的读取延迟

4. **数据宽度**：
   - 读操作始终读取整个字（32位）
   - 不支持字节级或半字级的部分读取
   - 如需读取部分字节，由Master在读取后自行提取

**握手延迟分析：**

最快情况（假设Slave立即读取完成）：
```
T0: 空闲状态
T1: Master在上升沿拉起req=1，地址准备好
T2: Slave采样地址并从内存读取数据，ack=0
T3: Slave拉高ack=1并提供rdata（读操作完成）
T4: Master采样到ack=1和rdata，握手成功，req拉低
```

延迟情况（Slave需要多个周期读取）：
```
T0: 空闲状态
T1: Master在上升沿拉起req=1
T2-Tn: Slave从内存读取数据，ack=0（读取中）
Tn+1: Slave拉高ack=1并提供rdata（读操作完成）
Tn+2: Master采样到ack=1和rdata，握手成功，req拉低
```

