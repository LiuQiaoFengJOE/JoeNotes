# HMB协议介绍

## 信号接口表

| 信号名 | 位宽 | 方向 | 说明 |
|--------|------|------|------|
| ip_hmb_vld | 1 | Master→Slave | hmb valid（请求有效信号） |
| ip_hmb_rdy | 1 | Slave→Master | hmb ready（就绪信号） |
| ip_hmb_rw | 1 | Master→Slave | 0:read, 1:write（读写控制） |
| ip_hmb_addr[31:0] | 32 | Master→Slave | hmb address（访问地址） |
| ip_hmb_size | 1 | Master→Slave | 0:128Bits, 256Bits（传输大小） |
| ip_hmb_wmask[15:0] | 16 | Master→Slave | 0:byte enable, 1:byte mask（写字节掩码） |
| ip_hmb_wdata[127:0] | 128 | Master→Slave | hmb write data（写数据） |
| ip_hmb_wrdy | 1 | Slave→Master | hmb write ready（写就绪信号） |
| ip_hmb_rrdy | 1 | Slave→Master | hmb read ready（读就绪信号） |
| ip_hmb_rdata[127:0] | 128 | Slave→Master | hmb read data（读数据） |
| ip_hmb_lat[7:0] | 8 | Master→Slave | latency input（DDR内存控制器仲裁控制，最大允许延时值） |
| ip_hmb_burst | 1 | Master→Slave | 0:wrap, 1:incr（突发模式，当前仅支持wrap模式） |
| ip_hmb_pri | 1 | Master→Slave | 0:no hi-priority, 1:with hi-priority（优先级，当前仅支持普通优先级） |

**方向说明：**
- **Master→Slave**：信号由主控端（Master）发出，从设备端（Slave）接收
- **Slave→Master**：信号由从设备端（Slave）发出，主控端（Master）接收
- **Master**：通常是SSD控制器或DMA控制器，发起HMB访问请求
- **Slave**：通常是主机内存控制器（HMB），响应访问请求并提供数据

## 信号详细说明

### 控制信号（握手协议）
- **ip_hmb_vld**: HMB请求有效信号，主控端发起，高电平表示有效的HMB访问请求
- **ip_hmb_rdy**: HMB就绪信号，从设备端响应，高电平表示可以接收新的HMB请求
- **握手机制**: 只有当 `ip_hmb_vld` 和 `ip_hmb_rdy` 同时为高电平时，传输才真正发生（握手成功）
- **ip_hmb_rw**: 读写控制信号
  - 0: 读操作
  - 1: 写操作

### 地址和大小
- **ip_hmb_addr[31:0]**: HMB访问地址，32位地址总线
- **ip_hmb_size**: 传输大小控制
  - 0: 2 QW (Quad Word, 128Bits)
  - 1: 4 QW (256Bits)

### 写操作相关
- **ip_hmb_wmask[15:0]**: 写字节掩码
  - 0: 字节使能
  - 1: 字节屏蔽
- **ip_hmb_wdata[127:0]**: 写数据总线，128位宽
- **ip_hmb_wrdy**: 写就绪信号，表示写通道准备好接收数据

### 读操作相关
- **ip_hmb_rrdy**: 读就绪信号，表示读数据有效
- **ip_hmb_rdata[127:0]**: 读数据总线，128位宽

### 性能和优先级
- **ip_hmb_lat[7:0]**: DDR内存控制器仲裁控制，表示最大允许延时值（默认值：0）
- **ip_hmb_burst**: 突发传输模式（默认值：0，当前仅支持0模式）
  - 0: wrap模式（环绕）- 地址不递增，保持在16字节块内
  - 1: incr模式（递增）- 地址自动递增，支持跨边界访问（暂未使用）
- **ip_hmb_pri**: 优先级控制（默认值：0，当前仅支持0模式）
  - 0: 普通优先级
  - 1: 高优先级（暂未使用）

## 时序说明

### 1.Write 128 bit - HMB_SIZE=0

<img src="./write 128 bit (2QW, 4DW).svg" alt="HMB写操作时序图" width="100%">

> **说明**：此时序图展示的是`ip_hmb_size = 0`的情况，即传输2 QW（16字节，128位）数据。

#### 时序图说明

上图展示了HMB协议的写操作时序（`ip_hmb_size = 0`，传输128位数据）。写操作采用双阶段握手机制：地址阶段握手和数据阶段握手。

**关键特性：数据必须提前准备**
- Master在发起命令（T3）或之前就必须准备好wdata和wmask
- 不能等到wrdy拉高后才提供数据
- Slave在wrdy拉高时立即采样早已准备好的数据

**时钟周期分析：**

| 周期 | Master | Slave | 说明 |
|------|--------|-------|------|
| T0-T2 | 空闲 | 空闲 | 等待传输请求 |
| T3 | vld=1, addr/ctrl有效<br>**wdata/wmask已准备好** | rdy=0 | Master发起请求并准备数据 |
| T4 | 保持vld=1和所有信号稳定 | 检查内部状态<br>如果条件满足：<br>**rdy=1（上升沿拉高）**<br>**同时采样addr/ctrl**<br>如果条件不满足：rdy=0（背压） | Slave拉高rdy并同时采样命令 |
| T5 | 上升沿采样到rdy=1<br>地址握手成功<br>**vld拉低为0**<br>保持wdata/wmask稳定 | **在T5时钟上升沿拉低rdy为0**<br>检测到rdy=1（上一周期）<br>采样到size=0，**记录1个待处理写事务**<br>检查数据缓冲区<br>如果有空间：**wrdy=1（上升沿拉高）**<br>如果缓冲区满：**wrdy=0（产生背压）** | 双方确认地址握手<br>rdy和wrdy都只持续1个周期 |
| T6 | 上升沿采样到wrdy=1<br>数据握手成功<br>**可以改变wdata/wmask** | **没有待处理事务 wrdy拉低**<br>采样wdata/wmask（上升沿采样到上一周期的wrdy=1）<br>数据存入缓冲区 | 双方确认数据握手并采样数据 |
| T7+ | 信号复位 | 信号复位 | 传输完成 |

**详细握手流程：**

**阶段1：Master发起请求（T3周期）**

同时完成三件事：
1. **命令发起**：
   - `ip_hmb_vld = 1`
   - `ip_hmb_rw = 1`（写操作）
   - `ip_hmb_addr`, `ip_hmb_size = 0`（2 QW，128位）, `ip_hmb_lat`, `ip_hmb_burst`, `ip_hmb_pri`

2. **数据准备（关键）**：
   - `ip_hmb_wdata[127:0]`：必须在此时或之前准备好
   - `ip_hmb_wmask[15:0]`：必须在此时或之前准备好

3. **稳定性承诺**：
   - 命令信号（`ip_hmb_addr`, `ip_hmb_size = 0`, `ip_hmb_lat`, `ip_hmb_burst`, `ip_hmb_pri`）保持稳定，直到Master在T5采样到`ip_hmb_rdy = 1`
   - 数据信号（`ip_hmb_wdata[127:0]`, `ip_hmb_wmask[15:0]`）保持稳定，直到Master在T6采样到`ip_hmb_wrdy = 1`

**阶段2：Slave拉高rdy并采样命令（T4周期）**

Slave端操作（在T4时钟上升沿同时完成）：
- 检查内部状态：
  - 当前是否有未处理完的资源冲突
  - 是否可以接收新的写事务
- 如果条件满足，在T4时钟上升沿**同时完成**：
  - 拉高`ip_hmb_rdy = 1`
  - 采样地址和控制信号（`ip_hmb_addr`, `ip_hmb_rw`, `ip_hmb_size`, `ip_hmb_lat`, `ip_hmb_burst`, `ip_hmb_pri`）
- 如果条件不满足，保持`ip_hmb_rdy = 0`（产生背压）

> **关键时序特性**：
> - Slave在拉高rdy的同一个时钟上升沿就采样命令信号，不需要等待下一个周期


**阶段3：Master确认地址握手（T5周期）**

Master端：
- 在T5时钟上升沿采样到`ip_hmb_rdy = 1`
- 确认地址握手成功
- **拉低`ip_hmb_vld = 0`**
- 之后可以改变命令信号（addr, size, lat, burst, pri）
- 但必须继续保持数据信号稳定

Slave端：
- **在T5时钟上升沿拉低`ip_hmb_rdy = 0`**
- 命令信号已在T4采样完成
- 上升沿检测到上一周期rdy=1（地址握手已完成）
- 采样到size=0，**记录1个待处理写事务**
- 追踪"已接收命令但尚未接收数据"的任务数量
- 检查数据缓冲区状态：
  - **如果缓冲区有空间**：在T5时钟上升沿拉高`ip_hmb_wrdy = 1`（主动向Master"索要"数据）
  - **如果缓冲区已满**：保持`ip_hmb_wrdy = 0`（产生背压），延迟拉高wrdy，直到缓冲区有空间

> 注意：
> - `ip_hmb_rdy = 1`表示vld和rdy在T4时都为高，地址握手已完成
> - 如果Slave在T4保持rdy=0（背压），则`ip_hmb_rdy`保持为0，Master的命令必须继续保持不变等待
> - **数据缓冲区满时**，wrdy保持为0（产生背压），Master必须保持wdata/wmask稳定并等待

**阶段4：数据握手成功（T6周期）**

Master端：
- 在T6时钟上升沿采样到`ip_hmb_wrdy = 1`
- 确认数据握手成功
- **之后可以改变`ip_hmb_wdata`和`ip_hmb_wmask`**或发起新的传输

Slave端：
- **在T6时钟上升沿拉低`ip_hmb_wrdy = 0`**（wrdy仅持续1个周期）
- 同时采样上一周期的数据：
  - `ip_hmb_wdata[127:0]`
  - `ip_hmb_wmask[15:0]`
- 采样的是Master早已准备好并保持稳定的数据
- 将数据和掩码存入内部缓冲区

**阶段5：完成（T7周期）**
- 返回空闲状态

**关键时序要求：**

1. **数据提前准备（T3）**：
   - Master不能等wrdy拉高后才提供数据
   - 数据必须在发起命令或之前就准备好
   - 这是与标准握手协议的重要区别

2. **信号稳定性**：
   - **命令信号**（addr, size, lat, burst, pri，vld）：从T3开始保持稳定，直到Master在T5采样到rdy=1
   - **数据信号**（wdata, wmask）：从T3开始或之前保持稳定，直到Master在T6采样到wrdy=1
   - Master必须等待采样到对应的握手信号后，才能改变信号

3. **快速响应（理想情况）**：
   - T3：Master发起请求
   - T4：Slave拉高rdy
   - T5：Master采样到rdy，地址握手成功；Slave拉高wrdy
   - T6：Master采样到wrdy，数据握手成功；Slave采样写数据
   - 总共4个周期完成

4. **背压支持（实际情况）**：
   - Slave在T4检查内部状态，决定是否拉高rdy
   - 如果内部忙碌（资源冲突、缓冲区满），保持rdy=0产生背压
   - 如果数据缓冲区满，可以在T5延迟拉高wrdy
   - Master必须等待，不能改变信号
   - 这是流量控制的关键机制
 

**握手延迟分析：**

最快情况（4个周期）：
```
T3: Master发起，数据准备好
T4: Slave拉高rdy并同时采样addr/ctrl
T5: Master采样到rdy，地址握手成功；Slave拉高wrdy
T6: Master采样到wrdy，数据握手成功；Slave采样wdata/wmask
```

背压情况（可能更多周期）：
```
T3: Master发起
T4-Tn: Slave背压，rdy=0（等待资源）
Tn+1: Slave拉高rdy并同时采样addr/ctrl
Tn+2: Master采样到rdy，地址握手成功
      如果数据缓冲区有空间：Slave拉高wrdy
      如果数据缓冲区满：Slave延迟拉高wrdy（wrdy=0，产生背压）
Tn+3-Tm: 如果数据缓冲区满，继续等待
Tm+1: Slave拉高wrdy（数据缓冲区有空间）
Tm+2: Master采样到wrdy，数据握手成功；Slave采样wdata/wmask
```

### 2. 写操作时序图 (Write 256 bit - HMB_SIZE=1)

<img src="./write 256 bit (4QW, 8DW).svg" alt="HMB写操作时序图 256bit" width="100%">

> **说明**：此时序图展示的是`ip_hmb_size = 1`的情况，即传输4 QW（32字节，256位）数据。

#### 时序图说明

上图展示了HMB协议的256位写操作时序（`ip_hmb_size = 1`）。与128位传输的主要区别是：由于数据总线宽度为128位，传输256位数据需要进行两次数据握手（两次wrdy握手），每次传输128位。

**关键差异：**
- `ip_hmb_size = 1`：需要传输4 QW（32字节，256位）
- 数据总线宽度：128位
- 数据传输次数：2次（第一次传输低128位，第二次传输高128位）
- 地址握手：1次（与128位传输相同）
- 数据握手：2次（与128位传输的主要区别）
- 总周期数：5个周期（T3-T7）

**时钟周期分析：**

| 周期 | Master | Slave | 说明 |
|------|--------|-------|------|
| T0-T2 | 空闲 | 空闲 | 等待传输请求 |
| T3 | vld=1, addr/ctrl有效<br>**第一个128位wdata/wmask已准备好** | rdy=0 | Master发起请求并准备第一个数据 |
| T4 | 保持vld=1和所有信号稳定 | rdy=1（上升沿拉高）<br>同时采样addr/ctrl | Slave拉高rdy并同时采样命令 |
| T5 | 采样到rdy=1<br>地址握手成功<br>**vld拉低为0**<br>保持第一个wdata/wmask稳定 | **rdy拉低为0**<br>检测到rdy=1（上一周期）<br>采样到size=1，记录2个待处理写事务（需要2次数据传输）<br>检查数据缓冲区<br>如果有空间：**wrdy=1（上升沿拉高）** | 双方确认地址握手
| T6 |采样到wrdy=1<br>第一次数据握手成功<br>**送出第二个128位wdata/wmask** | 采样第一个wdata/wmask（当采样到wrdy=1）<br>数据存入缓冲区<br>检查缓冲区和下游状态<br>如果有空间且下游准备好：**wrdy保持为1**<br>如果缓冲区满或下游未准备好：**wrdy拉低为0** | 第一次数据传输完成
| T7 | 采样到wrdy=1（第二次）<br>第二次数据握手成功<br>**之后可以改变wdata/wmask** | **没有待处理事务wrdy拉低**<br>采样第二个wdata/wmask（当采样到wrdy=1）<br>数据存入缓冲区 | 第二次数据传输完成 |
| T8+ | 信号复位 | 信号复位 | 传输完成 |
**详细握手流程：**

**阶段1-2：Master发起请求和Slave拉高rdy（T3-T4周期）**

与`ip_hmb_size = 0`的情况完全相同：
- T3：Master发起请求，准备第一个128位数据
- T4：Slave拉高rdy并同时采样命令信号


**阶段3：Master确认地址握手，Slave拉高第一次wrdy（T5周期）**

Master端：
- 在T5时钟上升沿采样到`ip_hmb_rdy = 1`
- 确认地址握手成功
- **拉低`ip_hmb_vld = 0`**
- 之后可以改变命令信号（addr, size, lat, burst, pri）
- 但必须继续保持第一个数据信号稳定

Slave端：
- **在T5时钟上升沿拉低`ip_hmb_rdy = 0`**（rdy仅持续1个周期）
- 命令信号已在T4采样完成
- 检测到上一周期rdy=1（地址握手已完成）
- **关键差异**：由于`ip_hmb_size = 1`，内部记录**2个**"待处理的写事务"
- 追踪"已接收命令但尚未接收数据"的任务数量：需要2次数据传输（每次128位）
- 检查数据缓冲区状态：
  - **如果缓冲区有空间**：在T5时钟上升沿拉高`ip_hmb_wrdy = 1`（主动向Master"索要"第一个数据）
  - **如果缓冲区已满**：保持`ip_hmb_wrdy = 0`（产生背压），延迟拉高wrdy，直到缓冲区有空间

> **重要**：这是与size=0的关键区别。size=1时，Slave知道需要接收两次128位数据（共256位）才能完成完整的传输。

**阶段4：第一次数据握手成功，Slave拉高第二次wrdy（T6周期）**

Master端：
- 在T6时钟上升沿采样到`ip_hmb_wrdy = 1`
- 确认第一次数据握手成功
- **在上升沿立即送出第二个128位数据**：更新`ip_hmb_wdata[127:0]`和`ip_hmb_wmask[15:0]`为第二个数据

Slave端：
- 同时采样上一周期的第一个数据：
  - `ip_hmb_wdata[127:0]`（第一个128位）
  - `ip_hmb_wmask[15:0]`（第一个掩码）
- 将数据存入内部缓冲区
- 更新待处理事务计数：还剩1个待处理事务
- 检查数据缓冲区状态：
  - **如果缓冲区有空间**：在T6时钟上升沿继续拉高`ip_hmb_wrdy = 1`（主动向Master"索要"第二个数据）
  - **如果缓冲区已满**：拉低`ip_hmb_wrdy = 0`（产生背压），延迟拉高wrdy

**阶段5：第二次数据握手成功（T7周期）**

Master端：

- 在T7时钟上升沿采样到`ip_hmb_wrdy = 1`
- 确认第二次数据握手成功
- 上升沿可以改变`ip_hmb_wdata`和`ip_hmb_wmask`或发起新的传输

Slave端：
- **在T7时钟上升沿拉低`ip_hmb_wrdy = 0`**
- 同时在上升沿采样上一周期的第二个数据：
  - `ip_hmb_wdata[127:0]`（第二个128位）
  - `ip_hmb_wmask[15:0]`（第二个掩码）
- 将数据存入内部缓冲区
- 更新待处理事务计数：所有事务完成
- 完整的256位数据已接收完毕

**阶段6：完成（T8周期）**
- 返回空闲状态

**关键时序要求：**

1. **两次数据准备**：
   - 第一个128位：在T3发起命令时准备好
   - 第二个128位：在T6第一次数据握手完成后立即送出
   - 每个数据必须保持稳定直到对应的wrdy握手完成

2. **两次wrdy握手**：
   - **最快情况（wrdy连续保持高电平）**：
     - T5：wrdy拉高
     - T6：wrdy保持为1，完成第一次握手，同时继续第二次握手
     - T7：完成第二次握手，wrdy拉低
     - wrdy连续2个周期为高（T5-T6）
   - **背压情况（wrdy分两次拉高）**：
     - T5：第一次wrdy拉高（仅1个周期）
     - T6：第一次握手完成，wrdy拉低（如果缓冲区满或下游未准备好）
     - Tn：等待缓冲区有空间
     - Tn+1：第二次wrdy拉高（仅1个周期）
     - Tn+2：第二次握手完成

3. **快速响应（理想情况）**：
   - T3：Master发起请求
   - T4：Slave拉高rdy
   - T5：地址握手成功，Slave拉高wrdy
   - T6：第一次数据握手成功，wrdy保持为1
   - T7：第二次数据握手成功，wrdy拉低
   - 总共5个周期完成（T3-T7）

4. **Master的关键责任**：
   - 第一次wrdy握手完成后（T6），必须立即送出第二个128位数据（更新`ip_hmb_wdata`和`ip_hmb_wmask`）
   - 保持每个数据稳定直到对应的wrdy握手完成
   - T7时钟上升沿采样到第二次wrdy=1后，可以改变wdata和wmask

5. **信号持续时间（取决于缓冲区和下游状态）**：
   - rdy信号：仅持续1个周期（T4拉高，T5拉低）
   - wrdy信号：
     - **最快情况**：连续2个周期为高（T5-T6），在T7拉低
     - **背压情况**：分两次拉高，每次仅持续1个周期
   - vld信号：从T3保持到T5拉低

**握手延迟分析：**

最快情况（5个周期，wrdy连续保持高电平）：
```
T3: Master发起，第一个128位数据准备好
T4: Slave拉高rdy并同时采样addr/ctrl
T5: Master采样到rdy，地址握手成功；Master拉低vld；Slave拉低rdy，拉高wrdy
T6: Master采样到wrdy，第一次数据握手成功；Slave采样第一个wdata/wmask，wrdy保持为1；Master送出第二个128位数据
T7: Master采样到wrdy，第二次数据握手成功；Slave拉低wrdy，采样第二个wdata/wmask
```

> **关键优化**：在最快情况下，wrdy在T5和T6连续2个周期保持为1，实现连续数据握手，无需等待。

背压情况（数据缓冲区满或下游未准备好）：
```
T3: Master发起，第一个128位数据准备好
T4-Tn: Slave可能背压，rdy=0（等待资源）
Tn+1: Slave拉高rdy并同时采样addr/ctrl
Tn+2: Master采样到rdy，地址握手成功；Master拉低vld；Slave拉低rdy
      检查数据缓冲区状态：
      - 如果缓冲区有空间：Slave拉高wrdy
      - 如果缓冲区满：Slave保持wrdy=0（产生背压）
Tn+3-Tm: 如果缓冲区满，等待缓冲区有空间
Tm+1: Slave拉高wrdy（数据缓冲区有空间，仅持续1个周期）
Tm+2: Master采样到wrdy，第一次数据握手成功；Slave采样第一个wdata/wmask；Master送出第二个128位数据
      检查缓冲区和下游状态：
      - 如果缓冲区有空间且下游准备好：Slave拉高wrdy（wrdy保持为1，连续握手）
      - 如果缓冲区满或下游未准备好：Slave保持wrdy=0（产生背压）
Tm+3: 如果wrdy在Tm+2保持为1：
        Master采样到wrdy，第二次数据握手成功；Slave拉低wrdy，采样第二个wdata/wmask
      如果wrdy在Tm+2为0：
        继续等待缓冲区有空间或下游准备好
Tm+3-Tk: 等待条件满足
Tk+1: Slave拉高wrdy（条件满足，仅持续1个周期）
Tk+2: Master采样到wrdy，第二次数据握手成功；Slave拉低wrdy，采样第二个wdata/wmask
```

### 3. Read 128 bit - HMB_SIZE=0

<img src="./read 128 bit (2QW, 4DW).svg" alt="HMB读操作时序图" width="100%">

> **说明**：此时序图展示的是`ip_hmb_size = 0`的情况，即读取2 QW（16字节，128位）数据。

#### 时序图说明

上图展示了HMB协议的读操作时序（`ip_hmb_size = 0`，读取128位数据）。读操作采用双阶段握手机制：地址阶段握手和数据阶段握手。

**关键特性：数据由Slave提供**
- Master在发起命令（T3）时只需提供地址和控制信号
- 不需要提供wdata和wmask（读操作不使用这些信号）
- Slave在rrdy拉高时提供rdata给Master采样

**时钟周期分析：**

| 周期 | Master | Slave | 说明 |
|------|--------|-------|------|
| T0-T2 | 空闲 | 空闲 | 等待传输请求 |
| T3 | vld=1, addr/ctrl有效<br>**rw=0（读操作）** | rdy=0 | Master发起读请求 |
| T4 | 保持vld=1和所有信号稳定 | 检查内部状态<br>如果条件满足：<br>**rdy=1（上升沿拉高）**<br>**同时采样addr/ctrl**<br>如果条件不满足：rdy=0（背压） | Slave拉高rdy并同时采样命令 |
| T5 | 采样到rdy=1<br>地址握手成功<br>**vld拉低为0**<br>等待读数据 | **在T5时钟上升沿拉低rdy为0**<br>检测到rdy=1（上一周期）<br>采样到size=0，**记录1个待处理读事务**<br>开始准备读数据 | 双方确认地址握手<br>
| T6-Tn | 等待rrdy | 从内存读取数据<br>准备rdata<br> | 等待数据准备完成 |
| Tn+1 | 等待rrdy | **rrdy=1（上升沿拉高）**<br>**rdata有效**<br>| Slave拉高rrdy并提供数据 |
| Tn+2 | 采样到rrdy=1<br>**采样rdata[127:0]**<br>数据握手成功 | **rrdy拉低为0**<br>rdata保持稳定 | Master采样读数据 |
| Tn+3+ | 信号复位 | 信号复位 | 传输完成 |

**详细握手流程：**

**阶段1：Master发起读请求（T3周期）**

Master端操作：
1. **命令发起**：
   - `ip_hmb_vld = 1`
   - `ip_hmb_rw = 0`（读操作）
   - `ip_hmb_addr`, `ip_hmb_size = 0`（2 QW，128位）, `ip_hmb_lat`, `ip_hmb_burst`, `ip_hmb_pri`

2. **稳定性承诺**：
   - 命令信号（`ip_hmb_addr`, `ip_hmb_size = 0`, `ip_hmb_lat`, `ip_hmb_burst`, `ip_hmb_pri`）保持稳定，直到Master在T5采样到`ip_hmb_rdy = 1`

**阶段2：Slave拉高rdy并采样命令（T4周期）**

Slave端操作（在T4时钟上升沿同时完成）：
- 检查内部状态：
  - 当前是否有未处理完的资源冲突
  - 是否可以接收新的读事务
- 如果条件满足，在T4时钟上升沿**同时完成**：
  - 拉高`ip_hmb_rdy = 1`
  - 采样地址和控制信号（`ip_hmb_addr`, `ip_hmb_rw`, `ip_hmb_size`, `ip_hmb_lat`, `ip_hmb_burst`, `ip_hmb_pri`）
- 如果条件不满足，保持`ip_hmb_rdy = 0`（产生背压）

> **关键时序特性**：
> - Slave在拉高rdy的同一个时钟上升沿就采样命令信号，不需要等待下一个周期

**阶段3：Master确认地址握手（T5周期）**

Master端：
- 在T5时钟上升沿采样到`ip_hmb_rdy = 1`
- 确认地址握手成功
- **拉低`ip_hmb_vld = 0`**
- 之后可以改变命令信号（addr, size, lat, burst, pri）
- 等待Slave提供读数据

Slave端：
- **在T5时钟上升沿拉低`ip_hmb_rdy = 0`**
- 命令信号已在T4采样完成
- 上升沿检测到上一周期rdy=1（地址握手已完成）
- 采样到size=0，**记录1个待处理读事务**
- 开始从内存读取数据，准备rdata

> 注意：
> - `ip_hmb_rdy = 1`表示vld和rdy在T4时都为高，地址握手已完成
> - 如果Slave在T4保持rdy=0（背压），则`ip_hmb_rdy`保持为0，Master的命令必须继续保持不变等待

**阶段4：Slave准备读数据（T6-Tn周期）**

Slave端：
- 根据采样的地址从内存读取数据
- 准备`ip_hmb_rdata[127:0]`
- 读取延迟取决于内存访问时间和系统负载

Master端：
- 等待`ip_hmb_rrdy`信号
- 保持空闲状态

**阶段5：数据握手成功（Tn+1-Tn+2周期）**

Slave端（Tn+1周期）：
- 数据准备完成
- 在Tn+1时钟上升沿**同时完成**：
  - 拉高`ip_hmb_rrdy = 1`（**仅持续1个周期**）
  - 提供`ip_hmb_rdata[127:0]`（读数据有效）

Master端（Tn+2周期）：
- 在Tn+2时钟上升沿采样到`ip_hmb_rrdy = 1`
- **同时采样`ip_hmb_rdata[127:0]`**
- 确认数据握手成功

Slave端（Tn+2周期）：
- **在Tn+2时钟上升沿拉低`ip_hmb_rrdy = 0`**
- rdata可以改变或复位

**阶段6：完成（Tn+3周期）**
- 返回空闲状态

**关键时序要求：**

1. **读操作特点**：
   - Master只需提供地址和控制信号，不需要提供数据
   - Slave负责从内存读取数据并通过rdata提供给Master
   - 读延迟不固定，取决于内存访问时间

2. **信号稳定性**：
   - **命令信号**（addr, size, lat, burst, pri，vld）：从T3开始保持稳定，直到Master在T5采样到rdy=1
   - **读数据信号**（rdata）：Slave在rrdy=1时提供，Master在下一个周期采样
   - Master必须等待采样到rrdy=1后才能使用rdata

3. **快速响应（理想情况）**：
   - T3：Master发起读请求
   - T4：Slave拉高rdy并采样命令
   - T5：Master采样到rdy，地址握手成功
   - T6-Tn：Slave准备读数据
   - Tn+1：Slave拉高rrdy并提供rdata
   - Tn+2：Master采样到rrdy和rdata，数据握手成功
   - 总共至少4+n个周期完成（n为读延迟）

4. **背压支持（实际情况）**：
   - Slave在T4检查内部状态，决定是否拉高rdy
   - 如果内部忙碌（资源冲突），保持rdy=0产生背压
   - Master必须等待，不能改变信号
   - 这是流量控制的关键机制


**握手延迟分析：**

最快情况（4+n个周期，n为读延迟）：
```
T3: Master发起读请求
T4: Slave拉高rdy并同时采样addr/ctrl
T5: Master采样到rdy，地址握手成功；Master拉低vld；Slave拉低rdy，开始准备读数据
T6-Tn: Slave从内存读取数据
Tn+1: Slave拉高rrdy并提供rdata
Tn+2: Master采样到rrdy和rdata，数据握手成功；Slave拉低rrdy
```

背压情况（可能更多周期）：
```
T3: Master发起读请求
T4-Tm: Slave背压，rdy=0（等待资源）
Tm+1: Slave拉高rdy并同时采样addr/ctrl
Tm+2: Master采样到rdy，地址握手成功；Master拉低vld；Slave拉低rdy，开始准备读数据
Tm+3-Tn: Slave从内存读取数据
Tn+1: Slave拉高rrdy并提供rdata
Tn+2: Master采样到rrdy和rdata，数据握手成功；Slave拉低rrdy
```


### 4. Read 256 bit - HMB_SIZE=1

<img src="./read 256 bit (4QW, 8DW).svg" alt="HMB读操作时序图 256bit" width="100%">

> **说明**：此时序图展示的是`ip_hmb_size = 1`的情况，即读取4 QW（32字节，256位）数据。

#### 时序图说明

上图展示了HMB协议的256位读操作时序（`ip_hmb_size = 1`）。与128位读取的主要区别是：由于数据总线宽度为128位，读取256位数据需要进行两次数据握手（两次rrdy握手），每次传输128位。

**关键差异：**
- `ip_hmb_size = 1`：需要读取4 QW（32字节，256位）
- 数据总线宽度：128位
- 数据传输次数：2次（第一次传输低128位，第二次传输高128位）
- 地址握手：1次（与128位读取相同）
- 数据握手：2次（与128位读取的主要区别）
- 总周期数：6+n个周期（T3-T8+n，n为读延迟）

**时钟周期分析：**

| 周期 | Master | Slave | 说明 |
|------|--------|-------|------|
| T0-T2 | 空闲 | 空闲 | 等待传输请求 |
| T3 | vld=1, addr/ctrl有效<br>**rw=0（读操作）** | rdy=0 | Master发起读请求 |
| T4 | 保持vld=1和所有信号稳定 | rdy=1（上升沿拉高）<br>同时采样addr/ctrl | Slave拉高rdy并同时采样命令 |
| T5 | 采样到rdy=1<br>地址握手成功<br>**vld拉低为0**<br>等待读数据 | **在T5时钟上升沿拉低rdy为0**<br>检测到rdy=1（上一周期）<br>采样到size=1，**记录2个待处理读事务**（需要2次数据传输）<br>开始准备读数据 | 双方确认地址握手<br>rdy只持续1个周期 |
| T6-Tn | 等待rrdy | 从内存读取数据<br>准备第一个128位rdata | 等待第一个数据准备完成 |
| Tn+1 | 等待rrdy | **rrdy=1（上升沿拉高）**<br>**rdata[127:0]有效（第一个128位）** | Slave拉高rrdy并提供第一个数据<br>**rrdy可能连续保持高电平** |
| Tn+2 | **采样第一个rdata[127:0]**<br>等待第二个数据 | 检查第二个数据状态：<br>**情况1**：如果第二个数据已准备好：**rrdy保持为1**，**rdata更新为第二个128位**<br>**情况2**：如果第二个数据未准备好：**rrdy拉低为0** | Master采样第一个数据<br>**rrdy是否保持高电平取决于第二个数据是否准备好** |
| Tn+3 | 如果rrdy在Tn+2保持为1：<br>**采样第二个rdata[127:0]**<br>第二次数据握手成功<br>如果rrdy在Tn+2为0：<br>等待rrdy | 如果rrdy在Tn+2保持为1：<br>**rrdy拉低为0**<br>如果rrdy在Tn+2为0：<br>继续准备第二个数据 | 第二次数据传输完成或继续等待 |
| Tn+3-Tm | 如果第二个数据未准备好，等待rrdy | 准备第二个128位数据 | 等待第二个数据准备完成 |
| Tm+1 | 等待rrdy | **rrdy=1（上升沿拉高）**<br>**rdata[127:0]有效（第二个128位）** | Slave拉高rrdy并提供第二个数据 |
| Tm+2 | **采样第二个rdata[127:0]**<br>第二次数据握手成功 | **rrdy拉低为0** | 第二次数据传输完成 |
| Tm+3+ | 信号复位 | 信号复位 | 传输完成 |

**详细握手流程：**

**阶段1-2：Master发起请求和Slave拉高rdy（T3-T4周期）**

与`ip_hmb_size = 0`的读操作完全相同：
- T3：Master发起读请求
- T4：Slave拉高rdy并同时采样命令信号

**阶段3：Master确认地址握手（T5周期）**

Master端：
- 在T5时钟上升沿采样到`ip_hmb_rdy = 1`
- 确认地址握手成功
- **拉低`ip_hmb_vld = 0`**
- 之后可以改变命令信号（addr, size, lat, burst, pri）
- 等待Slave提供第一个读数据

Slave端：
- **在T5时钟上升沿拉低`ip_hmb_rdy = 0`**（rdy仅持续1个周期）
- 命令信号已在T4采样完成
- 检测到上一周期rdy=1（地址握手已完成）
- **关键差异**：由于`ip_hmb_size = 1`，内部记录**2个**"待处理的读事务"
- 追踪"已接收命令但尚未发送数据"的任务数量：需要2次数据传输（每次128位）
- 开始从内存读取数据，准备第一个128位rdata
- **注意**：此时还未拉高rrdy，需要等待数据准备完成

> **重要**：这是与size=0的关键区别。size=1时，Slave知道需要发送两次128位数据（共256位）才能完成完整的传输。

**阶段4：Slave准备第一个读数据（T6-Tn周期）**

Slave端：
- 根据采样的地址从内存读取数据
- 准备第一个`ip_hmb_rdata[127:0]`（低128位）
- 读取延迟取决于内存访问时间和系统负载

Master端：
- 等待`ip_hmb_rrdy`信号
- 保持空闲状态

**阶段5：第一次数据握手完成，Slave决定是否保持rrdy（Tn+1-Tn+2周期）**

Slave端（Tn+1周期，例如T6）：
- 第一个数据准备完成
- 在Tn+1时钟上升沿**同时完成**：
  - 拉高`ip_hmb_rrdy = 1`
  - 提供第一个`ip_hmb_rdata[127:0]`（低128位数据有效）

Master端（Tn+2周期，例如T7）：
- 在Tn+2时钟上升沿**采样第一个`ip_hmb_rdata[127:0]`**
- 确认第一次数据握手成功
- 等待第二个数据

Slave端（Tn+2周期，例如T7）：
- **关键决策**：检查第二个数据状态，决定rrdy是否保持高电平
  - **情况1（最快）**：如果第二个数据已准备好：
    - **rrdy保持为1**（连续2个周期为高）
    - **rdata更新为第二个128位数据**
    - 可以在Tn+2和Tn+3连续提供两次数据
  - **情况2（延迟）**：如果第二个数据未准备好：
    - **在Tn+2时钟上升沿拉低`ip_hmb_rrdy = 0`**
    - 继续准备第二个数据，直到准备完成

> **重要发现**：根据实际情况，size=1时rrdy可以连续保持高电平！
> - 如果第二个数据在第一次握手时已准备好，rrdy可以在Tn+1和Tn+2连续2个周期保持为1
> - Slave在Tn+2时更新rdata为第二个128位数据
> - Master在Tn+3采样第二个数据，实现最快的数据传输

**阶段6：第二次数据握手成功（Tn+3或Tm+2周期）**

**情况1：rrdy连续保持高电平（最快，例如T6-T8）**

Master端（Tn+3周期，例如T8）：
- 在Tn+3时钟上升沿**采样第二个`ip_hmb_rdata[127:0]`**
- 确认第二次数据握手成功
- 完整的256位数据已接收完毕

Slave端（Tn+3周期，例如T8）：
- **在Tn+3时钟上升沿拉低`ip_hmb_rrdy = 0`**
- 更新待处理事务计数：所有事务完成

**情况2：rrdy分两次拉高（延迟）**

Slave端（Tn+3-Tm周期）：
- 继续准备第二个128位数据
- 数据准备完成后，在Tm+1时钟上升沿拉高`ip_hmb_rrdy = 1`
- 提供第二个`ip_hmb_rdata[127:0]`（高128位）

Master端（Tm+2周期）：
- 在Tm+2时钟上升沿采样到`ip_hmb_rrdy = 1`
- **同时采样第二个`ip_hmb_rdata[127:0]`**
- 确认第二次数据握手成功
- 完整的256位数据已接收完毕

Slave端（Tm+2周期）：
- **在Tm+2时钟上升沿拉低`ip_hmb_rrdy = 0`**
- 更新待处理事务计数：所有事务完成

**阶段7：完成（Tn+4或Tm+3周期）**
- 返回空闲状态

**关键时序要求：**

1. **两次数据提供**：
   - 第一个128位：在Tn+1提供（低128位）
   - 第二个128位：在Tn+2或Tm+1提供（高128位）
   - 每个数据在rrdy=1时有效，Master在下一个周期采样

2. **两次rrdy握手**：
   - **最快情况（rrdy连续保持高电平）**：
     - Tn+1：rrdy拉高
     - Tn+2：rrdy保持为1，完成第一次握手，同时继续第二次握手
     - Tn+3：完成第二次握手，rrdy拉低
     - rrdy连续2个周期为高（Tn+1-Tn+2）
   - **延迟情况（rrdy分两次拉高）**：
     - Tn+1：第一次rrdy拉高（仅1个周期）
     - Tn+2：第一次握手完成，rrdy拉低（第二个数据未准备好）
     - Tn+3-Tm：等待第二个数据准备完成
     - Tm+1：第二次rrdy拉高（仅1个周期）
     - Tm+2：第二次握手完成

3. **快速响应（理想情况）**：
   - T3：Master发起读请求
   - T4：Slave拉高rdy
   - T5：地址握手成功，Slave开始准备数据
   - T6-Tn：Slave准备第一个数据（假设n=3，即T6准备完成）
   - T6：Slave拉高rrdy并提供第一个rdata
   - T7：Master采样第一个rdata，rrdy保持为1，Slave提供第二个rdata
   - T8：Master采样第二个rdata，rrdy拉低
   - 总共6+n个周期完成（T3-T8，n为读延迟，最快情况n=3）

4. **Master的关键责任**：
   - 在rrdy=1的下一个周期采样rdata
   - 第一次采样（Tn+2，例如T7）：采样第一个128位数据
   - 第二次采样（Tn+3，例如T8）：采样第二个128位数据
   - 必须在每次rrdy=1后的上升沿采样对应的rdata

5. **信号持续时间（取决于数据准备状态）**：
   - rdy信号：仅持续1个周期（T4拉高，T5拉低）
   - rrdy信号：
     - **最快情况**：连续2个周期为高（Tn+1-Tn+2），在Tn+3拉低
     - **延迟情况**：分两次拉高，每次仅持续1个周期
   - vld信号：从T3保持到T5拉低

**握手延迟分析：**

最快情况（6+n个周期，rrdy连续保持高电平，假设n=3）：
```
T3: Master发起读请求
T4: Slave拉高rdy并同时采样addr/ctrl
T5: Master采样到rdy，地址握手成功；Master拉低vld；Slave拉低rdy，开始准备读数据
T6: Slave从内存读取数据完成，拉高rrdy并提供第一个rdata[127:0]（低128位）
T7: Master采样第一个rdata[127:0]；Slave的第二个数据已准备好，rrdy保持为1，rdata更新为第二个128位
T8: Master采样第二个rdata[127:0]；Slave拉低rrdy
```

> **关键优化**：在最快情况下，rrdy在T6和T7连续2个周期保持为1，Slave在T7更新rdata为第二个数据，Master在T7和T8连续采样两次数据，无需等待。

延迟情况（第二个数据未准备好）：
```
T3: Master发起读请求
T4-Tk: Slave可能背压，rdy=0（等待资源）
Tk+1: Slave拉高rdy并同时采样addr/ctrl
Tk+2: Master采样到rdy，地址握手成功；Master拉低vld；Slave拉低rdy，开始准备读数据
Tk+3-Tn: Slave从内存读取数据，准备第一个128位（假设n=6）
T6: Slave拉高rrdy并提供第一个rdata[127:0]（仅持续1个周期）
T7: Master采样第一个rdata[127:0]；Slave拉低rrdy，第二个数据未准备好
T8-Tm: Slave继续准备第二个128位数据（假设m=10）
T10: Slave拉高rrdy并提供第二个rdata[127:0]（仅持续1个周期）
T11: Master采样第二个rdata[127:0]；Slave拉低rrdy
```

> **读延迟说明**：
> - 第一次读延迟（n）：从地址握手完成（T5）到第一个数据准备好（Tn+1）的时间
> - 第二次读延迟（m）：从第一次数据采样（Tn+2）到第二个数据准备好（Tm+1）的时间
> - 如果内存访问效率高，第二个数据可能在第一次采样时已准备好，实现rrdy连续保持
> - 如果内存访问较慢，需要额外的延迟周期准备第二个数据
> - Master总是在rrdy=1的下一个周期采样rdata


