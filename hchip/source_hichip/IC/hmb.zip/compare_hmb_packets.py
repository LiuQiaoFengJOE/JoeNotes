#!/usr/bin/env python3
"""Reconstruct TS packets from HMB write traces and compare to the SSI source."""

import argparse
import re
import sys
from pathlib import Path


TRACE_RE = re.compile(
    r"txn=(?P<txn>\d+)\s+"
    r"(?:beat=(?P<beat>\d+)\s+beats=(?P<beats>\d+)\s+)?"
    r"rw=(?P<rw>\d+)\s+"
    r"addr=(?P<addr>[0-9a-fA-F]+)\s+"
    r"size=(?P<size>\d+)\s+"
    r"pri=(?P<pri>\d+)\s+"
    r"burst=(?P<burst>\d+)\s+"
    r"lat=(?P<lat>[0-9a-fA-F]+)\s+"
    r"wmask=(?P<wmask>[0-9a-fA-F]+)\s+"
    r"wdata=(?P<wdata>[0-9a-fA-F]+)\s+"
    r"rdata=(?P<rdata>[0-9a-fA-F]+)"
)
ASSI_SUMMARY_RE = re.compile(
    r"\[TB\]\s+ASSI summary bytes=(?P<bytes>\d+)\s+packets=(?P<packets>\d+)"
)


def parse_args():
    parser = argparse.ArgumentParser(
        description="Build packet text dumps from HMB writes and compare to TS packets."
    )
    parser.add_argument("trace", type=Path, help="HMB raw trace text file")
    parser.add_argument(
        "--reference-stream",
        required=True,
        type=Path,
        help="TS reference stream hex file",
    )
    parser.add_argument(
        "--base-addr",
        required=True,
        type=lambda value: int(value, 0),
        help="DMA base address used for this HMB writer",
    )
    parser.add_argument(
        "--actual-out",
        required=True,
        type=Path,
        help="Output text file for reconstructed actual packets",
    )
    parser.add_argument(
        "--expected-out",
        required=True,
        type=Path,
        help="Output text file for expected packets",
    )
    parser.add_argument(
        "--label",
        default="HMB",
        help="Short label for log messages",
    )
    parser.add_argument(
        "--packet-bytes",
        type=int,
        default=188,
        help="TS packet length in bytes",
    )
    parser.add_argument(
        "--sim-log",
        type=Path,
        help="Simulation log used to derive expected ASSI packet count",
    )
    parser.add_argument(
        "--expected-packets",
        type=int,
        help="Explicit expected packet count after HMB flush",
    )
    return parser.parse_args()


def load_trace(path):
    transactions = []
    for line_no, raw_line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        line = raw_line.strip()
        if not line:
            continue
        match = TRACE_RE.fullmatch(line)
        if not match:
            raise ValueError("Trace parse failed at line %d: %s" % (line_no, raw_line))
        fields = match.groupdict()
        transactions.append(
            {
                "txn": int(fields["txn"]),
                "beat": int(fields["beat"]) if fields["beat"] is not None else None,
                "beats": int(fields["beats"]) if fields["beats"] is not None else None,
                "rw": int(fields["rw"]),
                "addr": int(fields["addr"], 16),
                "size": int(fields["size"]),
                "pri": int(fields["pri"]),
                "burst": int(fields["burst"]),
                "lat": int(fields["lat"], 16),
                "wmask": int(fields["wmask"], 16),
                "wdata": int(fields["wdata"], 16),
                "rdata": int(fields["rdata"], 16),
            }
        )
    return transactions


def load_reference_packets(path, packet_bytes):
    tokens = []
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.split("//", 1)[0]
        tokens.extend(re.findall(r"\b[0-9a-fA-F]{2}\b", line))

    if not tokens:
        raise ValueError("No TS bytes found in reference stream: %s" % path)

    if (len(tokens) % packet_bytes) != 0:
        raise ValueError(
            "Reference stream length %d is not a multiple of packet size %d"
            % (len(tokens), packet_bytes)
        )

    packets = []
    for idx in range(0, len(tokens), packet_bytes):
        packet = [int(token, 16) for token in tokens[idx : idx + packet_bytes]]
        packets.append(packet)
    return packets


def load_assi_summary(path):
    summary = None
    for line_no, raw_line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        match = ASSI_SUMMARY_RE.search(raw_line)
        if match:
            summary = (
                int(match.group("bytes")),
                int(match.group("packets")),
                line_no,
            )

    if summary is None:
        raise ValueError("ASSI summary not found in sim log: %s" % path)

    return summary[0], summary[1]


def ensure_parent(path):
    path.parent.mkdir(parents=True, exist_ok=True)


def format_packet_line(packet_idx, dma_addr, ref_idx, packet_bytes, values):
    known = sum(1 for value in values if value is not None)
    data = " ".join("??" if value is None else ("%02x" % value) for value in values)
    return (
        "packet=%d dma_addr=%08x ref_packet=%d known=%d/%d data=%s"
        % (packet_idx, dma_addr, ref_idx, known, packet_bytes, data)
    )


def format_expected_line(packet_idx, dma_addr, ref_idx, values):
    data = " ".join("%02x" % value for value in values)
    return "packet=%d dma_addr=%08x ref_packet=%d data=%s" % (
        packet_idx,
        dma_addr,
        ref_idx,
        data,
    )


def build_packets(transactions, base_addr, packet_bytes):
    packet_map = {}
    conflicts = []

    for txn in transactions:
        if txn["rw"] != 1:
            continue

        for lane in range(16):
            if ((txn["wmask"] >> lane) & 1) != 0:
                continue

            abs_addr = txn["addr"] + lane
            if abs_addr < base_addr:
                continue

            rel_addr = abs_addr - base_addr
            packet_idx = rel_addr // packet_bytes
            packet_off = rel_addr % packet_bytes
            packet = packet_map.setdefault(packet_idx, [None] * packet_bytes)
            value = (txn["wdata"] >> (lane * 8)) & 0xff
            prev = packet[packet_off]

            if (prev is not None) and (prev != value):
                conflicts.append(
                    "packet=%d off=0x%02x prev=%02x new=%02x txn=%d addr=%08x"
                    % (packet_idx, packet_off, prev, value, txn["txn"], txn["addr"])
                )

            packet[packet_off] = value

    return packet_map, conflicts


def ranges_from_offsets(offsets):
    if not offsets:
        return "-"
    ranges = []
    start = offsets[0]
    end = offsets[0]
    for value in offsets[1:]:
        if value == (end + 1):
            end = value
        else:
            ranges.append((start, end))
            start = value
            end = value
    ranges.append((start, end))
    return ", ".join(
        ("0x%03x" % start) if start == end else ("0x%03x-0x%03x" % (start, end))
        for start, end in ranges
    )


def ranges_from_numbers(values):
    if not values:
        return "-"
    ranges = []
    start = values[0]
    end = values[0]
    for value in values[1:]:
        if value == (end + 1):
            end = value
        else:
            ranges.append((start, end))
            start = value
            end = value
    ranges.append((start, end))
    return ", ".join(
        ("%d" % start) if start == end else ("%d-%d" % (start, end))
        for start, end in ranges
    )


def main():
    args = parse_args()

    try:
        transactions = load_trace(args.trace)
        reference_packets = load_reference_packets(args.reference_stream, args.packet_bytes)
        expected_packets = args.expected_packets
        if args.sim_log is not None:
            _, sim_packets = load_assi_summary(args.sim_log)
            if expected_packets is None:
                expected_packets = sim_packets
            elif expected_packets != sim_packets:
                raise ValueError(
                    "expected packet count mismatch: arg=%d sim_log=%d"
                    % (expected_packets, sim_packets)
                )
    except (FileNotFoundError, ValueError) as exc:
        print("[HMB_PKT][ERR] %s %s" % (args.label, exc), file=sys.stderr)
        return 1

    packet_map, conflicts = build_packets(
        transactions=transactions,
        base_addr=args.base_addr,
        packet_bytes=args.packet_bytes,
    )

    if not packet_map:
        print("[HMB_PKT][ERR] %s no write packets reconstructed from trace" % args.label, file=sys.stderr)
        return 1

    ensure_parent(args.actual_out)
    ensure_parent(args.expected_out)

    actual_lines = []
    expected_lines = []
    errors = []
    packet_indices = sorted(packet_map)

    if expected_packets is not None:
        if expected_packets <= 0:
            print(
                "[HMB_PKT][ERR] %s invalid expected packet count %d"
                % (args.label, expected_packets),
                file=sys.stderr,
            )
            return 1
        missing_indices = [idx for idx in range(expected_packets) if idx not in packet_map]
        missing_index_set = set(missing_indices)
        extra_indices = [idx for idx in packet_indices if idx >= expected_packets]
        compare_indices = list(range(expected_packets)) + extra_indices
    else:
        missing_indices = []
        missing_index_set = set()
        extra_indices = []
        compare_indices = packet_indices

    for packet_idx in compare_indices:
        actual_packet = packet_map.get(packet_idx, [None] * args.packet_bytes)
        ref_idx = packet_idx % len(reference_packets)
        expected_packet = reference_packets[ref_idx]
        dma_addr = args.base_addr + packet_idx * args.packet_bytes

        actual_lines.append(
            format_packet_line(packet_idx, dma_addr, ref_idx, args.packet_bytes, actual_packet)
        )
        expected_lines.append(
            format_expected_line(packet_idx, dma_addr, ref_idx, expected_packet)
        )

        if packet_idx in missing_index_set:
            continue

        unknown_offsets = [idx for idx, value in enumerate(actual_packet) if value is None]
        mismatch_offsets = [
            idx
            for idx, value in enumerate(actual_packet)
            if (value is not None) and (value != expected_packet[idx])
        ]

        if unknown_offsets:
            errors.append(
                "%s packet=%d incomplete unknown=%d ranges=%s"
                % (
                    args.label,
                    packet_idx,
                    len(unknown_offsets),
                    ranges_from_offsets(unknown_offsets),
                )
            )

        if mismatch_offsets:
            first = mismatch_offsets[0]
            errors.append(
                "%s packet=%d mismatch off=0x%03x exp=%02x got=%02x"
                % (
                    args.label,
                    packet_idx,
                    first,
                    expected_packet[first],
                    actual_packet[first],
                )
            )

    if expected_packets is not None:
        if len(packet_map) != expected_packets:
            errors.append(
                "%s packet_count mismatch exp=%d got=%d"
                % (args.label, expected_packets, len(packet_map))
            )

        if missing_indices:
            errors.append(
                "%s missing packets ranges=%s"
                % (args.label, ranges_from_numbers(missing_indices))
            )

            tail_first = expected_packets
            while (tail_first > 0) and ((tail_first - 1) in missing_index_set):
                tail_first -= 1
            if tail_first != expected_packets:
                errors.append(
                    "%s tail packets not flushed ranges=%s"
                    % (
                        args.label,
                        ranges_from_numbers(list(range(tail_first, expected_packets))),
                    )
                )

        if extra_indices:
            errors.append(
                "%s unexpected packets ranges=%s"
                % (args.label, ranges_from_numbers(extra_indices))
            )

        tail_packet_idx = expected_packets - 1
        tail_packet = packet_map.get(tail_packet_idx)
        if tail_packet is not None:
            tail_unknown_offsets = [
                idx for idx, value in enumerate(tail_packet) if value is None
            ]
            if tail_unknown_offsets:
                errors.append(
                    "%s tail packet=%d not flushed unknown=%d ranges=%s"
                    % (
                        args.label,
                        tail_packet_idx,
                        len(tail_unknown_offsets),
                        ranges_from_offsets(tail_unknown_offsets),
                    )
                )

    args.actual_out.write_text("\n".join(actual_lines) + "\n", encoding="utf-8")
    args.expected_out.write_text("\n".join(expected_lines) + "\n", encoding="utf-8")

    if conflicts:
        print("[HMB_PKT][ERR] %s write conflicts detected:" % args.label, file=sys.stderr)
        for item in conflicts[:8]:
            print("  %s" % item, file=sys.stderr)
        if len(conflicts) > 8:
            print("  ... %d more conflicts" % (len(conflicts) - 8), file=sys.stderr)
        return 1

    if errors:
        print("[HMB_PKT][ERR] %s packet compare failed" % args.label, file=sys.stderr)
        for item in errors[:8]:
            print("  %s" % item, file=sys.stderr)
        if len(errors) > 8:
            print("  ... %d more issues" % (len(errors) - 8), file=sys.stderr)
        print("  actual  : %s" % args.actual_out, file=sys.stderr)
        print("  expected: %s" % args.expected_out, file=sys.stderr)
        return 1

    print(
        "[HMB_PKT] %s matched %d packet(s)%s; dumps: %s %s"
        % (
            args.label,
            len(packet_map),
            "" if expected_packets is None else (" / expected %d" % expected_packets),
            args.actual_out,
            args.expected_out,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
