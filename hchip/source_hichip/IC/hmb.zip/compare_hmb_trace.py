#!/usr/bin/env python3
"""Compare expected and actual HMB trace text files."""

import argparse
import sys
from itertools import zip_longest
from pathlib import Path


def parse_args():
    parser = argparse.ArgumentParser(
        description="Compare two HMB trace text files and report the first mismatch."
    )
    parser.add_argument("expected", type=Path, help="Expected HMB trace text file")
    parser.add_argument("actual", type=Path, help="Actual HMB trace text file")
    parser.add_argument(
        "--label",
        default="HMB",
        help="Short label used in compare messages",
    )
    return parser.parse_args()


def load_lines(path):
    return [
        line.strip()
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def main() -> int:
    args = parse_args()

    try:
        expected = load_lines(args.expected)
        actual = load_lines(args.actual)
    except FileNotFoundError as exc:
        print(f"[HMB_CMP][ERR] {args.label} missing file: {exc}", file=sys.stderr)
        return 1

    for line_no, (exp_line, act_line) in enumerate(
        zip_longest(expected, actual, fillvalue=None), start=1
    ):
        if exp_line != act_line:
            print(
                f"[HMB_CMP][ERR] {args.label} mismatch at line {line_no}",
                file=sys.stderr,
            )
            print(f"  expected: {exp_line or '<missing>'}", file=sys.stderr)
            print(f"  actual  : {act_line or '<missing>'}", file=sys.stderr)
            return 1

    print(f"[HMB_CMP] {args.label} matched ({len(actual)} lines)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
