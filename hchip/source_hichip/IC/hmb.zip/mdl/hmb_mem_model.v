module hmb_mem_model (
    input               clk,
    input               resetn,
    input               hmb_vld,
    output reg          hmb_rdy,
    input               hmb_rw,
    input       [31:0]  hmb_addr,
    input               hmb_size,
    input       [15:0]  hmb_wmask,
    input       [127:0] hmb_wdata,
    output reg          hmb_wrdy,
    output reg          hmb_rrdy,
    output reg  [127:0] hmb_rdata
);
    localparam STRESS_MODE = 1'b1;

    reg [127:0] mem_line [0:1023];
    integer i;

    reg         wr_active;
    reg         rd_active;
    reg [31:0]  wr_base_addr;
    reg [31:0]  rd_base_addr;
    reg [1:0]   wr_beats_left;
    reg [1:0]   rd_beats_left;
    reg [1:0]   wr_beat_idx;
    reg [1:0]   rd_beat_idx;
    reg [1:0]   rd_latency_cnt;
    reg [3:0]   cycle_cnt;
    reg [31:0]  prng;
    reg [1:0]   rd_gap_cnt;

    wire cmd_hs = hmb_vld & hmb_rdy;

    task automatic apply_masked_write(
        input [31:0]  addr,
        input [127:0] wdata,
        input [15:0]  wmask
    );
        reg [127:0] line;
        integer b;
        integer idx;
        begin
            idx = addr[13:4];
            line = mem_line[idx];
            for (b = 0; b < 16; b = b + 1) begin
                if (!wmask[b]) begin
                    line[b*8 +: 8] = wdata[b*8 +: 8];
                end
            end
            mem_line[idx] = line;
        end
    endtask

    always @(posedge clk or negedge resetn) begin
        if (!resetn) begin
            hmb_rdy      <= 1'b0;
            hmb_wrdy     <= 1'b0;
            hmb_rrdy     <= 1'b0;
            hmb_rdata    <= 128'd0;
            wr_active    <= 1'b0;
            rd_active    <= 1'b0;
            wr_base_addr <= 32'd0;
            rd_base_addr <= 32'd0;
            wr_beats_left<= 2'd0;
            rd_beats_left<= 2'd0;
            wr_beat_idx  <= 2'd0;
            rd_beat_idx  <= 2'd0;
            rd_latency_cnt <= 2'd0;
            cycle_cnt    <= 4'd0;
            prng         <= 32'h1ACE_B00C;
            rd_gap_cnt   <= 2'd0;
            for (i = 0; i < 1024; i = i + 1) begin
                mem_line[i] <= 128'd0;
            end
        end else begin
            cycle_cnt <= cycle_cnt + 1'b1;
            // xorshift-like PRNG for deterministic but irregular backpressure
            prng <= {prng[30:0], prng[31] ^ prng[21] ^ prng[1] ^ prng[0]};

            // address channel backpressure
            if (STRESS_MODE) begin
                hmb_rdy <= (cycle_cnt[2:0] != 3'b111) && (prng[2:1] != 2'b00);
            end else begin
                hmb_rdy <= (cycle_cnt[2:0] != 3'b111);
            end

            // default deassert data handshakes, raise when needed below
            hmb_wrdy <= 1'b0;
            hmb_rrdy <= 1'b0;

            if (cmd_hs) begin
                if (hmb_rw) begin
                    wr_active      <= 1'b1;
                    wr_base_addr   <= hmb_addr;
                    wr_beats_left  <= hmb_size ? 2'd2 : 2'd1;
                    wr_beat_idx    <= 2'd0;
                end else begin
                    rd_active      <= 1'b1;
                    rd_base_addr   <= hmb_addr;
                    rd_beats_left  <= hmb_size ? 2'd2 : 2'd1;
                    rd_beat_idx    <= 2'd0;
                    rd_latency_cnt <= 2'd2;
                end
            end

            if (wr_active && (wr_beats_left != 0)) begin
                if (!STRESS_MODE || (prng[6:5] != 2'b00)) begin
                    hmb_wrdy <= 1'b1;
                    apply_masked_write(wr_base_addr + {28'd0, wr_beat_idx, 4'd0}, hmb_wdata, hmb_wmask);
                    wr_beat_idx   <= wr_beat_idx + 1'b1;
                    wr_beats_left <= wr_beats_left - 1'b1;
                    if (wr_beats_left == 1) begin
                        wr_active <= 1'b0;
                    end
                end
            end

            if (rd_active && (rd_beats_left != 0)) begin
                if (rd_latency_cnt != 0) begin
                    rd_latency_cnt <= rd_latency_cnt - 1'b1;
                end else if (rd_gap_cnt != 0) begin
                    rd_gap_cnt <= rd_gap_cnt - 1'b1;
                end else begin
                    // rrdy may be delayed/gapped to emulate non-ideal response alignment
                    if (!STRESS_MODE || (prng[10:9] != 2'b00)) begin
                        hmb_rrdy  <= 1'b1;
                        hmb_rdata <= mem_line[((rd_base_addr + {28'd0, rd_beat_idx, 4'd0}) >> 4)];
                        rd_beat_idx   <= rd_beat_idx + 1'b1;
                        rd_beats_left <= rd_beats_left - 1'b1;
                        if (rd_beats_left == 1) begin
                            rd_active <= 1'b0;
                            rd_gap_cnt <= 2'd0;
                        end else if (STRESS_MODE) begin
                            rd_gap_cnt <= prng[12:11]; // insert 0..3 cycle gap between beat0/beat1
                        end
                    end
                end
            end
        end
    end

endmodule

