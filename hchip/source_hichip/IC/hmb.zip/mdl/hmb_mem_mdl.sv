`timescale 1ns/1ps

module hmb_mem_mdl #(
    parameter integer DEPTH_WORDS = 1024,
    parameter integer ADDR_LSB    = 4,
    parameter string  TRACE_FILE  = ""
) (
    input  wire         clk,
    input  wire         resetn,
    input  wire         hmb_vld,
    output reg          hmb_rdy,
    input  wire         hmb_rw,
    input  wire [31:0]  hmb_addr,
    input  wire         hmb_size,
    output reg          hmb_wrdy,
    output reg [127:0]  hmb_rdata,
    output reg          hmb_rrdy,
    input  wire [15:0]  hmb_wmask,
    input  wire [127:0] hmb_wdata,
    input  wire         hmb_pri,
    input  wire         hmb_burst,
    input  wire [7:0]   hmb_lat,
    output reg [31:0]   txn_count,
    output reg [31:0]   rw0_count,
    output reg [31:0]   rw1_count
);

reg [127:0] mem [0:DEPTH_WORDS-1];
integer i;
integer trace_fd;
reg [31:0] trace_txn_idx;
reg         cmd_active;
reg [31:0]  cmd_txn_idx;
reg         cmd_rw_reg;
reg [31:0]  cmd_addr_reg;
reg         cmd_size_reg;
reg         cmd_pri_reg;
reg         cmd_burst_reg;
reg  [7:0]  cmd_lat_reg;
reg         wr_active;
reg  [1:0]  wr_beats_left;
reg  [1:0]  wr_beat_idx;
reg  [31:0] wr_txn_idx;
reg  [31:0] wr_base_addr;
reg         wr_size_reg;
reg         wr_pri_reg;
reg         wr_burst_reg;
reg  [7:0]  wr_lat_reg;
reg         rd_active;
reg  [1:0]  rd_beats_left;
reg  [1:0]  rd_beat_idx;
reg  [31:0] rd_txn_idx;
reg  [31:0] rd_base_addr;
reg         rd_size_reg;
reg         rd_pri_reg;
reg         rd_burst_reg;
reg  [7:0]  rd_lat_reg;

function automatic integer word_index(
    input [31:0] addr_i
);
begin
    word_index = addr_i[ADDR_LSB + 9:ADDR_LSB] % DEPTH_WORDS;
end
endfunction

function automatic [31:0] beat_addr_of(
    input [31:0] base_addr_i,
    input [1:0]  beat_idx_i
);
begin
    beat_addr_of = base_addr_i + ({30'd0, beat_idx_i} << ADDR_LSB);
end
endfunction

function automatic [127:0] read_word(
    input [31:0] addr_i
);
integer idx_local;
begin
    idx_local = word_index(addr_i);
    read_word = mem[idx_local];
end
endfunction

task automatic log_read_beat(
    input [31:0]  txn_idx_i,
    input [1:0]   beat_idx_i,
    input [1:0]   beats_total_i,
    input [31:0]  addr_i,
    input         size_i,
    input         pri_i,
    input         burst_i,
    input [7:0]   lat_i,
    input [127:0] rdata_i
);
begin
    if (trace_fd != 0) begin
        $fdisplay(trace_fd,
                  "txn=%0d beat=%0d beats=%0d rw=%0d addr=%08x size=%0d pri=%0d burst=%0d lat=%02x wmask=%04x wdata=%032x rdata=%032x",
                  txn_idx_i, beat_idx_i, beats_total_i, 1'b0,
                  addr_i, size_i, pri_i, burst_i, lat_i, 16'h0000, 128'h0, rdata_i);
        $fflush(trace_fd);
    end
end
endtask

task automatic capture_write_beat(
    input [31:0]  txn_idx_i,
    input [1:0]   beat_idx_i,
    input [1:0]   beats_total_i,
    input [31:0]  addr_i,
    input         size_i,
    input         pri_i,
    input         burst_i,
    input [7:0]   lat_i,
    input [15:0]  wmask_i,
    input [127:0] wdata_i
);
integer idx_local;
integer lane_local;
reg [127:0] old_rdata;
begin
    idx_local = word_index(addr_i);
    old_rdata = mem[idx_local];

    if ((^wmask_i !== 1'bx) && (^wdata_i !== 1'bx)) begin
        if (trace_fd != 0) begin
            $fdisplay(trace_fd,
                      "txn=%0d beat=%0d beats=%0d rw=%0d addr=%08x size=%0d pri=%0d burst=%0d lat=%02x wmask=%04x wdata=%032x rdata=%032x",
                      txn_idx_i, beat_idx_i, beats_total_i, 1'b1,
                      addr_i, size_i, pri_i, burst_i, lat_i, wmask_i, wdata_i, old_rdata);
            $fflush(trace_fd);
        end

        for (lane_local = 0; lane_local < 16; lane_local = lane_local + 1) begin
            if (!wmask_i[lane_local]) begin
                mem[idx_local][lane_local*8 +: 8] <= wdata_i[lane_local*8 +: 8];
            end
        end
    end
end
endtask

initial begin
    trace_fd = 0;
    if (TRACE_FILE != "") begin
        trace_fd = $fopen(TRACE_FILE, "w");
        if (trace_fd == 0) begin
            $display("[HMB_MDL][ERR] failed to open trace file: %0s", TRACE_FILE);
            $finish;
        end
    end
end

final begin
    if (trace_fd != 0) begin
        $fclose(trace_fd);
    end
end

always @(posedge clk or negedge resetn) begin
    if (!resetn) begin
        hmb_rdy   <= 1'b0;
        hmb_wrdy  <= 1'b0;
        hmb_rrdy  <= 1'b0;
        hmb_rdata <= 128'h0;
        txn_count <= 32'd0;
        rw0_count <= 32'd0;
        rw1_count <= 32'd0;
        trace_txn_idx <= 32'd0;
        cmd_active <= 1'b0;
        cmd_txn_idx <= 32'd0;
        cmd_rw_reg <= 1'b0;
        cmd_addr_reg <= 32'd0;
        cmd_size_reg <= 1'b0;
        cmd_pri_reg <= 1'b0;
        cmd_burst_reg <= 1'b0;
        cmd_lat_reg <= 8'd0;
        wr_active <= 1'b0;
        wr_beats_left <= 2'd0;
        wr_beat_idx <= 2'd0;
        wr_txn_idx <= 32'd0;
        wr_base_addr <= 32'd0;
        wr_size_reg <= 1'b0;
        wr_pri_reg <= 1'b0;
        wr_burst_reg <= 1'b0;
        wr_lat_reg <= 8'd0;
        rd_active <= 1'b0;
        rd_beats_left <= 2'd0;
        rd_beat_idx <= 2'd0;
        rd_txn_idx <= 32'd0;
        rd_base_addr <= 32'd0;
        rd_size_reg <= 1'b0;
        rd_pri_reg <= 1'b0;
        rd_burst_reg <= 1'b0;
        rd_lat_reg <= 8'd0;
        for (i = 0; i < DEPTH_WORDS; i = i + 1) begin
            mem[i] <= {32'hA5A5_0000 + i[31:0], 32'h5A5A_0000 + i[31:0], 32'h1234_0000 + i[31:0], 32'h5678_0000 + i[31:0]};
        end
    end else begin
        // Registered HMB handshake: command accept first, then beat transfer on wrdy/rrdy.
        hmb_rdy  <= 1'b0;
        hmb_wrdy <= 1'b0;
        hmb_rrdy <= 1'b0;

        if (hmb_wrdy && wr_active) begin
            capture_write_beat(wr_txn_idx, wr_beat_idx, wr_size_reg ? 2'd2 : 2'd1,
                               beat_addr_of(wr_base_addr, wr_beat_idx),
                               wr_size_reg, wr_pri_reg, wr_burst_reg, wr_lat_reg,
                               hmb_wmask, hmb_wdata);

            if (wr_beats_left == 2'd1) begin
                wr_active <= 1'b0;
                wr_beats_left <= 2'd0;
                wr_beat_idx <= 2'd0;
            end else begin
                wr_beats_left <= wr_beats_left - 1'b1;
                wr_beat_idx <= wr_beat_idx + 1'b1;
                hmb_wrdy <= 1'b1;
            end
        end

        if (hmb_rrdy && rd_active) begin
            if (rd_beats_left == 2'd1) begin
                rd_active <= 1'b0;
                rd_beats_left <= 2'd0;
                rd_beat_idx <= 2'd0;
            end else begin
                rd_beats_left <= rd_beats_left - 1'b1;
                rd_beat_idx <= rd_beat_idx + 1'b1;
                hmb_rdata <= read_word(beat_addr_of(rd_base_addr, rd_beat_idx + 1'b1));
                log_read_beat(rd_txn_idx, rd_beat_idx + 1'b1, rd_size_reg ? 2'd2 : 2'd1,
                              beat_addr_of(rd_base_addr, rd_beat_idx + 1'b1),
                              rd_size_reg, rd_pri_reg, rd_burst_reg, rd_lat_reg,
                              read_word(beat_addr_of(rd_base_addr, rd_beat_idx + 1'b1)));
                hmb_rrdy <= 1'b1;
            end
        end

        if (hmb_rdy && cmd_active) begin
            cmd_active <= 1'b0;
            if (cmd_rw_reg) begin
                wr_active <= 1'b1;
                wr_beats_left <= cmd_size_reg ? 2'd2 : 2'd1;
                wr_beat_idx <= 2'd0;
                wr_txn_idx <= cmd_txn_idx;
                wr_base_addr <= cmd_addr_reg;
                wr_size_reg <= cmd_size_reg;
                wr_pri_reg <= cmd_pri_reg;
                wr_burst_reg <= cmd_burst_reg;
                wr_lat_reg <= cmd_lat_reg;
                hmb_wrdy <= 1'b1;
            end else begin
                rd_active <= 1'b1;
                rd_beats_left <= cmd_size_reg ? 2'd2 : 2'd1;
                rd_beat_idx <= 2'd0;
                rd_txn_idx <= cmd_txn_idx;
                rd_base_addr <= cmd_addr_reg;
                rd_size_reg <= cmd_size_reg;
                rd_pri_reg <= cmd_pri_reg;
                rd_burst_reg <= cmd_burst_reg;
                rd_lat_reg <= cmd_lat_reg;
                hmb_rdata <= read_word(cmd_addr_reg);
                log_read_beat(cmd_txn_idx, 2'd0, cmd_size_reg ? 2'd2 : 2'd1,
                              cmd_addr_reg, cmd_size_reg, cmd_pri_reg, cmd_burst_reg, cmd_lat_reg,
                              read_word(cmd_addr_reg));
                hmb_rrdy <= 1'b1;
            end
        end

        if (!cmd_active && !wr_active && !rd_active && !hmb_rdy && !hmb_wrdy && !hmb_rrdy && hmb_vld) begin
            hmb_rdy <= 1'b1;
            cmd_active <= 1'b1;
            cmd_txn_idx <= trace_txn_idx;
            cmd_rw_reg <= hmb_rw;
            cmd_addr_reg <= hmb_addr;
            cmd_size_reg <= hmb_size;
            cmd_pri_reg <= hmb_pri;
            cmd_burst_reg <= hmb_burst;
            cmd_lat_reg <= hmb_lat;
            txn_count <= txn_count + 1'b1;
            if (hmb_rw) begin
                rw1_count <= rw1_count + 1'b1;
            end else begin
                rw0_count <= rw0_count + 1'b1;
            end
            trace_txn_idx <= trace_txn_idx + 1'b1;
        end
    end
end

endmodule
